import streamlit as st
import pickle
import pandas as pd
import requests
from dotenv import load_dotenv
import os

load_dotenv()

API_KEY = os.getenv("TMDB_API_KEY")
def fetch_poster(movie_id):
   response = requests.get(
    f'https://api.themoviedb.org/3/movie/{movie_id}?api_key={API_KEY}'
)
   data = response.json()
   print(data)
   return "https://image.tmdb.org/t/p/w500/" + data['poster_path']

def recommend(movie):
    movie_idx = movies[movies['title'] == movie].index[0]
    movies_list = similarity_top5[movie_idx]  #CHANGE
    recommended_movies=[]
    recommended_movies_poster =[]
    for i in movies_list:
        movie_id = movies.iloc[i].movie_id  #CHANGE
        recommended_movies.append(movies.iloc[i].title)  #CHANGE
        #to fetch poster of the id movie from api
        recommended_movies_poster.append(fetch_poster(movie_id))
    return recommended_movies,recommended_movies_poster
movies_dict = pickle.load(open('movies_dict.pkl','rb'))
movies = pd.DataFrame(movies_dict)
similarity_top5 = pickle.load(open('similarity_top5.pkl','rb'))  #CHANGE

st.title('Movie Recommender System')


option = st.selectbox(
'Select a movie',
movies['title'].values
)
#st.write(option)
if st.button('Recommend'):
    names,poster = recommend(option)

    col1,col2,col3,col4,col5 = st.columns(5)
    with col1:
        st.text(names[0])
        st.image(poster[0])
    with col2:
        st.text(names[1])
        st.image(poster[1]) 
    with col3:
        st.text(names[2])
        st.image(poster[2]) 
    with col4:
        st.text(names[3])
        st.image(poster[3]) 
    with col5:
        st.text(names[4])
        st.image(poster[4])   

